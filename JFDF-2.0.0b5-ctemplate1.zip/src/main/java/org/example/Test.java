package org.example;

import net.jfdf.compiler.annotation.NoConstructors;
import net.jfdf.jfdf.blocks.PlayerEventBlock;
import net.jfdf.jfdf.mangement.PlayerEvent;

@NoConstructors
public class Test {
    @PlayerEvent(eventType = PlayerEventBlock.Event.JOIN)
    public static void onJoin() {
        System.out.println("Hello %default !");
    }
}
