package org.example;

import net.jfdf.addon.collections.CollectionsAddon;
import net.jfdf.addon.interaction.InteractionAddon;
import net.jfdf.addon.loc.LocAddon;
import net.jfdf.addon.math.MathAddon;
import net.jfdf.addon.random.RandomAddon;
import net.jfdf.addon.splitter.CodeSplitter;
import net.jfdf.addon.string.StringAddon;
import net.jfdf.addon.vector.VectorAddon;
import net.jfdf.compiler.EasyConfigurableCompiler;
import net.jfdf.compiler.addon.CompilerAddons;
import net.jfdf.jfdf.AddonsManager;
import net.jfdf.jfdf.mangement.CodeManager;

public class CompilerConfiguration extends EasyConfigurableCompiler {
    public static void main(String[] args) {
        EasyConfigurableCompiler compiler = new CompilerConfiguration();
        compiler.compileAndSend(String.join(" ", args));
    }

    @Override
    protected void configure() {
        CodeManager.checksumFunction = true;

        CodeSplitter.plotSize = CodeManager.PLOT_SIZE.BASIC;
        AddonsManager.registerAddon(new CodeSplitter());

        CompilerAddons.registerAddon(new CollectionsAddon());
        CompilerAddons.registerAddon(new InteractionAddon());
        CompilerAddons.registerAddon(new RandomAddon());
        CompilerAddons.registerAddon(new VectorAddon());
        CompilerAddons.registerAddon(new StringAddon());
        CompilerAddons.registerAddon(new MathAddon());
        CompilerAddons.registerAddon(new LocAddon());
    }
}
